import pygame
import random
import sysimport pygame
pygame.init()
print("¡Pygame instalado correctamente!")
pygame.quit()
pygame.init()

NEGRO = (0, 0, 0)
VERDE_SERPIENTE = (0, 200, 0)
VERDE_CABEZA = (0, 255, 0)
ROJO_COMIDA = (255, 50, 50)
BLANCO = (255, 255, 255)
GRIS_OSCURO = (40, 40, 40)
AMARILLO = (255, 255, 0)

ANCHO = 800
ALTO = 600
TAMAÑO_CELDA = 20


pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("🐍 Juego de la Serpiente")
reloj = pygame.time.Clock()

fuente_puntuacion = pygame.font.Font(None, 32)
fuente_game_over = pygame.font.Font(None, 48)
fuente_instrucciones = pygame.font.Font(None, 24)

class Serpiente:
    def __init__(self):
        centro_x = (ANCHO // 2 // TAMAÑO_CELDA) * TAMAÑO_CELDA
        centro_y = (ALTO // 2 // TAMAÑO_CELDA) * TAMAÑO_CELDA
        self.cuerpo = [
            (centro_x, centro_y),
            (centro_x - TAMAÑO_CELDA, centro_y),
            (centro_x - 2 * TAMAÑO_CELDA, centro_y)
        ]
        self.direccion = (TAMAÑO_CELDA, 0)  
        self.nueva_direccion = (TAMAÑO_CELDA, 0)
        self.crecer = False
    
    def actualizar_direccion(self):
        """Actualiza la dirección de la serpiente para evitar cambios bruscos"""
        self.direccion = self.nueva_direccion
    
    def mover(self):
        self.actualizar_direccion()
        cabeza_x, cabeza_y = self.cuerpo[0]

        nueva_cabeza = (cabeza_x + self.direccion[0], cabeza_y + self.direccion[1])
        self.cuerpo.insert(0, nueva_cabeza)
        if not self.crecer:
            self.cuerpo.pop()
        else:
            self.crecer = False
    
    def cambiar_direccion(self, nueva_direccion):
        """Cambiar dirección evitando que la serpiente se mueva en dirección opuesta"""
        dx, dy = self.direccion
        nuevo_dx, nuevo_dy = nueva_direccion
        if (dx, dy) != (-nuevo_dx, -nuevo_dy):
            self.nueva_direccion = nueva_direccion
    
    def colision_consigo_misma(self):
        """Verificar si la cabeza colisiona con el cuerpo"""
        return self.cuerpo[0] in self.cuerpo[1:]
    
    def colision_bordes(self):
        """Verificar si la serpiente choca con los bordes"""
        cabeza_x, cabeza_y = self.cuerpo[0]
        return (cabeza_x < 0 or cabeza_x >= ANCHO or 
                cabeza_y < 0 or cabeza_y >= ALTO)
    
    def dibujar(self, pantalla):
        """Dibujar la serpiente con cabeza diferenciada"""
        for i, segmento in enumerate(self.cuerpo):
            rect = pygame.Rect(segmento[0], segmento[1], TAMAÑO_CELDA, TAMAÑO_CELDA)
            if i == 0:  
                pygame.draw.rect(pantalla, VERDE_CABEZA, rect)
                pygame.draw.rect(pantalla, BLANCO, rect, 2)
                ojo1 = pygame.Rect(segmento[0] + 4, segmento[1] + 4, 4, 4)
                ojo2 = pygame.Rect(segmento[0] + 12, segmento[1] + 4, 4, 4)
                pygame.draw.rect(pantalla, NEGRO, ojo1)
                pygame.draw.rect(pantalla, NEGRO, ojo2)
            else:  
                pygame.draw.rect(pantalla, VERDE_SERPIENTE, rect)
                pygame.draw.rect(pantalla, GRIS_OSCURO, rect, 1)

class Comida:
    def __init__(self, serpiente_cuerpo=None):
        if serpiente_cuerpo is None:
            serpiente_cuerpo = []
        self.posicion = self.generar_posicion(serpiente_cuerpo)
    
    def generar_posicion(self, serpiente_cuerpo):
        """Generar posición aleatoria que no esté ocupada por la serpiente"""
        while True:
            x = random.randint(0, (ANCHO // TAMAÑO_CELDA) - 1) * TAMAÑO_CELDA
            y = random.randint(0, (ALTO // TAMAÑO_CELDA) - 1) * TAMAÑO_CELDA
            nueva_pos = (x, y)
            if nueva_pos not in serpiente_cuerpo:
                return nueva_pos
    
    def dibujar(self, pantalla):
        """Dibujar la comida como una manzana simple"""
        rect = pygame.Rect(self.posicion[0], self.posicion[1], TAMAÑO_CELDA, TAMAÑO_CELDA)
        pygame.draw.ellipse(pantalla, ROJO_COMIDA, rect)
        
        tallo = pygame.Rect(self.posicion[0] + 8, self.posicion[1] + 2, 4, 6)
        pygame.draw.rect(pantalla, VERDE_SERPIENTE, tallo)

def mostrar_puntuacion(pantalla, puntuacion, nivel):
    """Mostrar puntuación y nivel en pantalla"""
    texto_puntos = fuente_puntuacion.render(f"Puntos: {puntuacion}", True, BLANCO)
    texto_nivel = fuente_puntuacion.render(f"Nivel: {nivel}", True, AMARILLO)
    pantalla.blit(texto_puntos, (10, 10))
    pantalla.blit(texto_nivel, (10, 45))

def mostrar_game_over(pantalla, puntuacion, nivel):
    """Mostrar pantalla de game over"""
   
    overlay = pygame.Surface((ANCHO, ALTO))
    overlay.set_alpha(180)
    overlay.fill(NEGRO)
    pantalla.blit(overlay, (0, 0))
    
    
    texto_game_over = fuente_game_over.render("¡GAME OVER!", True, ROJO_COMIDA)
    texto_puntuacion = fuente_puntuacion.render(f"Puntuación final: {puntuacion}", True, BLANCO)
    texto_nivel = fuente_puntuacion.render(f"Nivel alcanzado: {nivel}", True, AMARILLO)
    texto_reiniciar = fuente_instrucciones.render("ESPACIO: Jugar de nuevo  |  ESC: Salir", True, BLANCO)
    
    
    rect_game_over = texto_game_over.get_rect(center=(ANCHO//2, ALTO//2 - 80))
    rect_puntuacion = texto_puntuacion.get_rect(center=(ANCHO//2, ALTO//2 - 20))
    rect_nivel = texto_nivel.get_rect(center=(ANCHO//2, ALTO//2 + 10))
    rect_reiniciar = texto_reiniciar.get_rect(center=(ANCHO//2, ALTO//2 + 60))
    
    pantalla.blit(texto_game_over, rect_game_over)
    pantalla.blit(texto_puntuacion, rect_puntuacion)
    pantalla.blit(texto_nivel, rect_nivel)
    pantalla.blit(texto_reiniciar, rect_reiniciar)

def mostrar_pausa(pantalla):
    """Mostrar mensaje de pausa"""
    overlay = pygame.Surface((ANCHO, ALTO))
    overlay.set_alpha(150)
    overlay.fill(NEGRO)
    pantalla.blit(overlay, (0, 0))
    
    texto_pausa = fuente_game_over.render("PAUSA", True, AMARILLO)
    texto_continuar = fuente_puntuacion.render("Presiona P para continuar", True, BLANCO)
    
    rect_pausa = texto_pausa.get_rect(center=(ANCHO//2, ALTO//2 - 30))
    rect_continuar = texto_continuar.get_rect(center=(ANCHO//2, ALTO//2 + 20))
    
    pantalla.blit(texto_pausa, rect_pausa)
    pantalla.blit(texto_continuar, rect_continuar)

def calcular_velocidad(nivel):
    """Calcular velocidad basada en el nivel"""
    return min(15, 8 + nivel)  

def juego_principal():
    serpiente = Serpiente()
    comida = Comida(serpiente.cuerpo)
    puntuacion = 0
    nivel = 1
    game_over = False
    pausado = False
    
    while True:
       
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if evento.type == pygame.KEYDOWN:
                if not game_over and not pausado:
                  
                    if evento.key == pygame.K_UP or evento.key == pygame.K_w:
                        serpiente.cambiar_direccion((0, -TAMAÑO_CELDA))
                    elif evento.key == pygame.K_DOWN or evento.key == pygame.K_s:
                        serpiente.cambiar_direccion((0, TAMAÑO_CELDA))
                    elif evento.key == pygame.K_LEFT or evento.key == pygame.K_a:
                        serpiente.cambiar_direccion((-TAMAÑO_CELDA, 0))
                    elif evento.key == pygame.K_RIGHT or evento.key == pygame.K_d:
                        serpiente.cambiar_direccion((TAMAÑO_CELDA, 0))
                    elif evento.key == pygame.K_p:
                        pausado = True
                elif pausado:
                    if evento.key == pygame.K_p:
                        pausado = False
                elif game_over:
                    if evento.key == pygame.K_SPACE:
                       
                        return juego_principal()
                    elif evento.key == pygame.K_ESCAPE:
                        pygame.quit()
                        sys.exit()
        
        if not game_over and not pausado:
            
            serpiente.mover()

            if serpiente.colision_consigo_misma() or serpiente.colision_bordes():
                game_over = True
            
            
            if serpiente.cuerpo[0] == comida.posicion:
                serpiente.crecer = True
                puntuacion += 10
                
              
                nuevo_nivel = (puntuacion // 50) + 1
                if nuevo_nivel > nivel:
                    nivel = nuevo_nivel
                
            
                comida = Comida(serpiente.cuerpo)
    
        pantalla.fill(NEGRO)
        
        
        if not game_over:
            serpiente.dibujar(pantalla)
            comida.dibujar(pantalla)
            mostrar_puntuacion(pantalla, puntuacion, nivel)
            
            if pausado:
                mostrar_pausa(pantalla)
        else:
           
            serpiente.dibujar(pantalla)
            comida.dibujar(pantalla)
            mostrar_game_over(pantalla, puntuacion, nivel)
        
        pygame.display.flip()
        
       
        velocidad = calcular_velocidad(nivel)
        reloj.tick(velocidad)

def mostrar_menu_inicio():
    """Mostrar menú inicial del juego"""
    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_SPACE:
                    return
                elif evento.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
        
        pantalla.fill(NEGRO)
        
        
        titulo = fuente_game_over.render("🐍 SNAKE GAME 🐍", True, VERDE_CABEZA)
        rect_titulo = titulo.get_rect(center=(ANCHO//2, ALTO//2 - 100))
        pantalla.blit(titulo, rect_titulo)
        
      
        instrucciones = [
            "Controles:",
            "Flechas o WASD: Mover",
            "P: Pausar/Reanudar",
            "ESC: Salir",
            "",
            "ESPACIO: Comenzar juego"
        ]
        
        for i, linea in enumerate(instrucciones):
            color = BLANCO if linea != "ESPACIO: Comenzar juego" else AMARILLO
            texto = fuente_instrucciones.render(linea, True, color)
            rect = texto.get_rect(center=(ANCHO//2, ALTO//2 - 20 + i * 25))
            pantalla.blit(texto, rect)
        
        pygame.display.flip()
        reloj.tick(30)

if __name__ == "__main__":
    try:
        mostrar_menu_inicio()
        juego_principal()
    except KeyboardInterrupt:
        pygame.quit()
        sys.exit()
    except Exception as e:
        print(f"Error: {e}")
        pygame.quit()
        sys.exit()